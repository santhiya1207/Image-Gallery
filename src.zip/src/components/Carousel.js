import React from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';
import './Carousel.css';

const ImageGallery = () => {
    return(
        <div>
            <Carousel>
                <div className="image">
                    <img src="../img1.jpg" />
                </div>
                <div className="image">
                    <img src="../img2.jpg" />
                </div>
                <div className="image">
                    <img src="../img3.jpg" />
                </div>
                <div className="image">
                    <img src="../img4.jpg" />
                </div>
                <div className="image">
                    <img src="../img5.jpg" />
                </div>
                <div className="image">
                    <img src="../img6.jpg" />
                </div>
                <div className="image">
                    <img src="../img7.jpg" />
                </div>
                <div className="image">
                    <img src="../img8.jpg" />
                </div>
                <div className="image">
                    <img src="../img9.jpg" />
                </div>
                <div className="image">
                    <img src="../img10.jpg" />
                </div>
                <div className="image">
                    <img src="../img11.jpg" />
                </div>
                <div className="image">
                    <img src="../img12.jpg" />
                </div>
                <div className="image">
                    <img src="../img13.jpg" />
                </div>
                <div className="image">
                    <img src="../img14.jpg" />
                </div>
                <div className="image">
                    <img src="../img15.jpg"/>
                </div>
            </Carousel>
        </div>
    )
}
export default ImageGallery;