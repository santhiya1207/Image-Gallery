import React from 'react';
import './App.css';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import ImageGallery from './components/Carousel';

function App() {
  return (
    <div className="App">
      <ImageGallery/>
    </div>
  );
}

export default App;